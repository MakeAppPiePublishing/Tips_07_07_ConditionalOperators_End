import UIKit

let goodPizza = "This is good Pizza"
let badPizza = "This is bad Pizza"
var rating:Int! = 5
var pizzaRating = ""

if rating > 5 {
    pizzaRating = goodPizza
} else {
    pizzaRating = badPizza
}

rating = nil
//rating = rating != nil ? rating : 0
//rating = rating ?? 0
pizzaRating = rating ?? 0 > 5 ? goodPizza : badPizza
pizzaRating = rating ?? 0 == 5 ? "So So pizza" : pizzaRating
print("The rating is \(rating ?? 0). \(pizzaRating)")
